# PMS_PA5
R functions for statistics 


Liens utiles:

Identifier la distribution d'un jeu de donnée:
https://stackoverflow.com/questions/31741742/how-to-identify-the-distribution-of-the-given-data-using-r

https://openclassrooms.com/fr/courses/4525306-initiez-vous-a-la-statistique-inferentielle/5016618-testez-une-moyenne-ou-une-variance

Rappel sur les intervalles de confiance : http://cedric.cnam.fr/~saporta/Rappels%20sur%20les%20intervalles%20de%20confiance.pdf
  - Fonction pivotale
  - Intervalles de confiance pour l’espérance 
  - Intervalles de confiance pour la variance 
  - Intervalles de confiance pour une proportion
  
  
Tests sur les hypothèses : 
http://images.icube.unistra.fr/fr/img_auth.php/4/4f/Hypo-1.pdf?fbclid=IwAR332lBDT6ebdTqbvcAAoI6BVkIO5ycps2LgwDw1jIFtcHIos2lfm4LG7RM


Fixer le risque de première espèce -> Le risque le plus grave c'est dire qu'il y a H1 alors qu'il y a H0
